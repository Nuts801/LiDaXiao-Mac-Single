#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
APP_NAME="李大霄桌宠"
EXECUTABLE="LiDaXiaoPet"
BUNDLE_ID="local.lidaxiao.desktop-pet"
VERSION="${PET_VERSION:-1.0.0}"
BUILD_NUMBER="${PET_BUILD:-1}"
APP="build/$APP_NAME.app"
PACKAGE=0
case "${1:-}" in
    "") ;;
    --package) PACKAGE=1 ;;
    *) echo "Usage: ./build.sh [--package]" >&2; exit 2 ;;
esac
[[ "$(uname -s)" == "Darwin" ]] || { echo "Build requires macOS." >&2; exit 1; }
[[ "$(uname -m)" == "arm64" ]] || { echo "Build requires Apple Silicon (arm64)." >&2; exit 1; }
[[ "$(sw_vers -productVersion | cut -d. -f1)" -ge 14 ]] || { echo "macOS 14+ required." >&2; exit 1; }
command -v swiftc >/dev/null || { echo "Install Xcode Command Line Tools: xcode-select --install" >&2; exit 1; }
[[ "$VERSION" =~ ^[0-9]+(\.[0-9]+){0,2}$ ]] || { echo "Invalid PET_VERSION" >&2; exit 1; }
[[ "$BUILD_NUMBER" =~ ^[0-9]+$ ]] || { echo "Invalid PET_BUILD" >&2; exit 1; }
# The fixed application path is the only build directory removed.
[[ "$APP" == "build/李大霄桌宠.app" ]] || exit 1
rm -rf -- "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
swiftc -O -target arm64-apple-macosx14.0 -framework AppKit -framework AVFoundation Sources/main.swift -o "$APP/Contents/MacOS/$EXECUTABLE"
cp -R Assets/. "$APP/Contents/Resources/"
cp LICENSE LICENSE-SunPet MATERIALS.md "$APP/Contents/Resources/"
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>$EXECUTABLE</string>
<key>CFBundleIdentifier</key><string>$BUNDLE_ID</string>
<key>CFBundleName</key><string>$APP_NAME</string>
<key>CFBundleDisplayName</key><string>$APP_NAME</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>$VERSION</string>
<key>CFBundleVersion</key><string>$BUILD_NUMBER</string>
<key>LSMinimumSystemVersion</key><string>14.0</string>
<key>LSUIElement</key><true/>
<key>NSHighResolutionCapable</key><true/>
<key>CFBundleIconFile</key><string>AppIcon</string>
</dict></plist>
PLIST
codesign --force --sign - "$APP"
codesign --verify --strict "$APP"
"$APP/Contents/MacOS/$EXECUTABLE" --self-test
if [[ "$PACKAGE" == "1" ]]; then
    mkdir -p dist
    ZIP="LiDaXiaoPet-macOS-arm64-$VERSION.zip"
    ditto -c -k --keepParent "$APP" "dist/$ZIP"
    (cd dist && shasum -a 256 "$ZIP" > "$ZIP.sha256")
    printf '分享包：dist/%s\n' "$ZIP"
fi
printf '已构建并通过自检：%s\n' "$APP"
