from pathlib import Path
import json, math, wave
from PIL import Image

root = Path(__file__).resolve().parents[1]
assets = root / 'Assets'
clips = json.loads((assets / 'clips.json').read_text(encoding='utf-8-sig'))
assert len(clips) == 10, 'Expected 10 clips'
assert {c['id'] for c in clips} == set(range(1, 11)), 'Invalid or duplicate clip IDs'
files = [c['file'] for c in clips]
assert len(set(files)) == len(files), 'Duplicate audio filenames'
assert {p.name for p in (assets / 'Clips').iterdir()} == set(files), 'Missing or stale audio files'
for clip in clips:
    assert Path(clip['file']).name == clip['file'] and '\\' not in clip['file']
    assert clip['label'].strip() and math.isfinite(clip['duration'])
    with wave.open(str(assets / 'Clips' / clip['file']), 'rb') as audio:
        assert (audio.getframerate(), audio.getsampwidth(), audio.getnchannels(), audio.getcomptype()) == (44100, 2, 1, 'NONE')
        duration = audio.getnframes() / audio.getframerate()
        assert duration > .25 and abs(duration - clip['duration']) < .01
    print(f"OK {clip['file']} {duration:.3f}s {clip['label']}")
with Image.open(assets / 'face.png') as image:
    alpha = image.convert('RGBA').getchannel('A')
    assert alpha.getextrema() == (0, 255) and alpha.getpixel((0, 0)) == 0
    print('OK transparent portrait', image.size)
with Image.open(assets / 'AppIcon.icns') as icon:
    icon.load()
    assert icon.size == (1024, 1024)
    assert icon.convert('RGBA').getchannel('A').getextrema() == (0, 255)
    print('OK ICNS icon', icon.size)
assert not (root / 'Sources' / 'Bridge.swift').exists()
print('PASS assets (macOS native build and UI validation still required)')
