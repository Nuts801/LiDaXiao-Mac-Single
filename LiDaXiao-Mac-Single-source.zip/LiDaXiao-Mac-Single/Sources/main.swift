import AppKit
import AVFoundation

// Interaction and playback design adapted from SunPet (MIT); see LICENSE-SunPet.
struct Clip: Codable {
    let id: Int
    let label: String
    let file: String
    let duration: Double
}

struct ShuffleBag {
    var remaining: [Int] = []
    var last: Int?
    mutating func next(count: Int) -> Int? {
        guard count > 0 else { return nil }
        if remaining.isEmpty {
            remaining = Array(0..<count).shuffled()
            if count > 1, remaining.last == last { remaining.swapAt(0, count - 1) }
        }
        let value = remaining.removeLast()
        last = value
        return value
    }
}

final class PetPanel: NSPanel {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
}
final class PassiveImage: NSImageView {
    override func hitTest(_ point: NSPoint) -> NSView? { nil }
}
final class PassiveLabel: NSTextField {
    override func hitTest(_ point: NSPoint) -> NSView? { nil }
}

final class PetView: NSView {
    weak var owner: AppDelegate?
    let face = PassiveImage()
    let caption = PassiveLabel(labelWithString: "")
    var initialMouse = NSPoint.zero
    var initialWindow = NSPoint.zero
    var dragged = false
    var animationTimer: Timer?
    var phase = 0.0
    var speaking = false

    override init(frame: NSRect) {
        super.init(frame: frame)
        wantsLayer = true
        face.imageScaling = .scaleProportionallyUpOrDown
        face.wantsLayer = true
        addSubview(face)
        caption.alignment = .center
        caption.textColor = .white
        caption.font = .systemFont(ofSize: 13, weight: .medium)
        caption.maximumNumberOfLines = 0
        caption.lineBreakMode = .byWordWrapping
        caption.wantsLayer = true
        caption.layer?.backgroundColor = NSColor.black.withAlphaComponent(0.76).cgColor
        caption.layer?.cornerRadius = 9
        caption.isHidden = true
        addSubview(caption)
        toolTip = "点击随机播放一句 · 拖动移动 · 右键设置"
        setAccessibilityElement(true)
        setAccessibilityRole(.button)
        setAccessibilityLabel("李大霄桌宠，点击随机播放一句，拖动移动，右键设置")
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    override func layout() {
        super.layout()
        let captionHeight = owner?.captionHeight ?? 34
        face.frame = NSRect(x: 8, y: 8, width: bounds.width - 16, height: bounds.height - captionHeight - 18)
        caption.frame = NSRect(x: 3, y: bounds.height - captionHeight - 4, width: bounds.width - 6, height: captionHeight)
    }
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
    override func mouseDown(with event: NSEvent) {
        initialMouse = window?.convertPoint(toScreen: event.locationInWindow) ?? NSEvent.mouseLocation
        initialWindow = window?.frame.origin ?? .zero
        dragged = false
    }
    override func mouseDragged(with event: NSEvent) {
        let current = window?.convertPoint(toScreen: event.locationInWindow) ?? NSEvent.mouseLocation
        let dx = current.x - initialMouse.x, dy = current.y - initialMouse.y
        if hypot(dx, dy) > 4 { dragged = true }
        if dragged { window?.setFrameOrigin(NSPoint(x: initialWindow.x + dx, y: initialWindow.y + dy)) }
    }
    override func mouseUp(with event: NSEvent) {
        if dragged { owner?.savePosition() } else { owner?.playNext() }
    }
    override func rightMouseDown(with event: NSEvent) {
        guard let menu = owner?.makeMenu() else { return }
        NSMenu.popUpContextMenu(menu, with: event, for: self)
    }
    override func accessibilityPerformPress() -> Bool { owner?.playNext(); return true }
    func animate(_ enabled: Bool) {
        speaking = enabled
        animationTimer?.invalidate(); animationTimer = nil
        phase = 0
        face.layer?.transform = CATransform3DIdentity
        guard enabled, !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else { return }
        animationTimer = Timer.scheduledTimer(withTimeInterval: 1.0 / 30.0, repeats: true) { [weak self] _ in
            guard let self else { return }
            self.phase += 0.60
            // Compress vertically by up to 12%, then return to the original height.
            let heightScale = 1.0 - 0.12 * (1.0 - cos(self.phase)) / 2.0
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            self.face.layer?.transform = CATransform3DMakeScale(1.0, heightScale, 1.0)
            CATransaction.commit()
        }
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate, AVAudioPlayerDelegate {
    var panel: PetPanel!
    var pet: PetView!
    var status: NSStatusItem!
    var player: AVAudioPlayer?
    var clips: [Clip] = []
    var bag = ShuffleBag()
    var lastPlayed: Int?
    var captionWork: DispatchWorkItem?
    var volume: Float = 0.65
    var size: CGFloat = 260
    var imageRatio: CGFloat = 1
    let selfTest = CommandLine.arguments.contains("--self-test")
    let defaults = UserDefaults.standard
    var resources: URL { Bundle.main.resourceURL! }
    // Reserve enough room for the longest caption, including at the smallest pet size.
    var captionHeight: CGFloat {
        let width = max(1, size - 16)
        let texts = clips.map { $0.label } + ["点我说一句 · 右键设置", "这句暂时无法播放"]
        let height = texts.map { text in
            (text as NSString).boundingRect(
                with: NSSize(width: width, height: CGFloat.greatestFiniteMagnitude),
                options: [.usesLineFragmentOrigin, .usesFontLeading],
                attributes: [.font: NSFont.systemFont(ofSize: 13, weight: .medium)]
            ).height
        }.max() ?? 0
        return max(34, ceil(height) + 8)
    }
    var panelSize: NSSize { NSSize(width: size, height: (size - 16) * imageRatio + captionHeight + 18) }

    func applicationDidFinishLaunching(_ notification: Notification) {
        if !selfTest, let id = Bundle.main.bundleIdentifier {
            let others = NSRunningApplication.runningApplications(withBundleIdentifier: id).filter { $0.processIdentifier != getpid() }
            if !others.isEmpty { NSApp.terminate(nil); return }
        }
        let image: NSImage
        do {
            clips = try JSONDecoder().decode([Clip].self, from: Data(contentsOf: resources.appendingPathComponent("clips.json")))
            guard !clips.isEmpty, let face = NSImage(contentsOf: resources.appendingPathComponent("face.png")), face.size.width > 0 else {
                throw NSError(domain: "素材缺失", code: 1)
            }
            guard Set(clips.map { $0.id }).count == clips.count,
                  Set(clips.map { $0.file }).count == clips.count else {
                throw NSError(domain: "语音编号或文件名重复", code: 4)
            }
            for clip in clips {
                guard clip.id > 0, !clip.label.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                      (clip.file as NSString).lastPathComponent == clip.file,
                      !clip.file.contains("\\"), clip.file.hasSuffix(".wav"),
                      clip.duration.isFinite, clip.duration > 0 else {
                    throw NSError(domain: "语音配置无效", code: 5)
                }
                guard FileManager.default.fileExists(atPath: resources.appendingPathComponent("Clips/\(clip.file)").path) else {
                    throw NSError(domain: "缺少音频：\(clip.file)", code: 2)
                }
            }
            image = face
        } catch {
            if selfTest { print("FAIL: \(error)"); exit(1) }
            let alert = NSAlert(); alert.messageText = "桌宠素材无法读取"; alert.informativeText = error.localizedDescription
            alert.runModal(); NSApp.terminate(nil); return
        }
        imageRatio = image.size.height / image.size.width
        if defaults.object(forKey: "volume") != nil { volume = min(max(defaults.float(forKey: "volume"), 0), 1) }
        if defaults.object(forKey: "size") != nil { size = min(max(CGFloat(defaults.double(forKey: "size")), 160), 400) }
        panel = PetPanel(contentRect: NSRect(origin: .zero, size: panelSize), styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        panel.title = "李大霄桌宠"
        panel.isOpaque = false; panel.backgroundColor = .clear; panel.hasShadow = false
        panel.level = .floating; panel.hidesOnDeactivate = false; panel.isReleasedWhenClosed = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
        pet = PetView(frame: NSRect(origin: .zero, size: panelSize)); pet.owner = self
        pet.face.image = image; panel.contentView = pet
        restorePosition()
        panel.orderFrontRegardless()
        status = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        status.button?.title = "大霄"
        status.button?.toolTip = "李大霄桌宠 · 点击打开设置"
        status.button?.target = self; status.button?.action = #selector(openStatusMenu)
        if selfTest { runSelfTest() } else { showCaption("点我说一句 · 右键设置", seconds: 5) }
    }
    func restorePosition() {
        if defaults.object(forKey: "petX") != nil {
            let origin = NSPoint(x: defaults.double(forKey: "petX"), y: defaults.double(forKey: "petY"))
            let rect = NSRect(origin: origin, size: panelSize)
            if NSScreen.screens.contains(where: { $0.visibleFrame.intersection(rect).width >= 80 && $0.visibleFrame.intersection(rect).height >= 80 }) {
                panel.setFrameOrigin(origin); return
            }
        }
        placeAtCorner()
    }
    func placeAtCorner() {
        guard let screen = NSScreen.main ?? NSScreen.screens.first else { return }
        panel.setFrameOrigin(NSPoint(x: screen.visibleFrame.maxX - panelSize.width - 32, y: screen.visibleFrame.minY + 24))
    }
    func savePosition() {
        guard !selfTest, let panel else { return }
        defaults.set(panel.frame.origin.x, forKey: "petX"); defaults.set(panel.frame.origin.y, forKey: "petY")
    }
    @objc func resetPosition() { placeAtCorner(); savePosition() }
    @objc func openStatusMenu() { status.menu = makeMenu(); status.button?.performClick(nil); status.menu = nil }
    func item(_ title: String, _ action: Selector?, tag: Int = 0) -> NSMenuItem {
        let result = NSMenuItem(title: title, action: action, keyEquivalent: "")
        result.target = self; result.tag = tag; return result
    }
    func makeMenu() -> NSMenu {
        let menu = NSMenu()
        let title = item("李大霄桌宠 · \(clips.count)句原声", nil); title.isEnabled = false; menu.addItem(title)
        let hint = item("点击随机播放 · 一轮内不重复", nil); hint.isEnabled = false; menu.addItem(hint)
        menu.addItem(.separator())
        menu.addItem(item("随机说一句", #selector(playNext)))
        let choose = item("挑一句", nil), choices = NSMenu()
        for clip in clips { choices.addItem(item(String(format: "%02d  %@", clip.id, clip.label), #selector(chooseClip(_:)), tag: clip.id)) }
        choose.submenu = choices; menu.addItem(choose)
        menu.addItem(item("停止播放", #selector(stopPlayback)))
        menu.addItem(.separator())
        let volumeItem = item("音量", nil), volumes = NSMenu()
        for value in [0, 25, 50, 65, 80, 100] {
            let option = item(value == 0 ? "静音" : "\(value)%", #selector(setVolume(_:)), tag: value)
            option.state = abs(volume - Float(value)/100) < 0.01 ? .on : .off; volumes.addItem(option)
        }
        volumeItem.submenu = volumes; menu.addItem(volumeItem)
        let sizeItem = item("人物大小", nil), sizes = NSMenu()
        for (name, value) in [("小", 190), ("中", 260), ("大", 340)] {
            let option = item(name, #selector(setSize(_:)), tag: value)
            option.state = Int(size) == value ? .on : .off; sizes.addItem(option)
        }
        sizeItem.submenu = sizes; menu.addItem(sizeItem)
        menu.addItem(item("移回屏幕右下角", #selector(resetPosition)))
        menu.addItem(.separator())
        menu.addItem(item("退出桌宠", #selector(quit)))
        return menu
    }
    @objc func playNext() {
        guard let index = bag.next(count: clips.count) else { return }
        play(clips[index])
    }
    func play(_ clip: Clip) {
        player?.stop(); pet.animate(false)
        do {
            let audio = try AVAudioPlayer(contentsOf: resources.appendingPathComponent("Clips/\(clip.file)"))
            player = audio; audio.delegate = self; audio.volume = volume; audio.prepareToPlay()
            guard audio.play() else { throw NSError(domain: "无法播放音频", code: 3) }
            lastPlayed = clip.id; pet.animate(true); showCaption(clip.label, seconds: audio.duration + 0.4)
        } catch { showCaption("这句暂时无法播放", seconds: 4) }
    }
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        guard player === self.player else { return }
        pet.animate(false)
    }
    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        guard player === self.player else { return }
        stopPlayback(); showCaption("音频读取失败", seconds: 4)
    }
    func showCaption(_ text: String, seconds: Double) {
        captionWork?.cancel(); pet.caption.stringValue = text; pet.caption.isHidden = false
        let work = DispatchWorkItem { [weak self] in self?.pet.caption.isHidden = true }
        captionWork = work; DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: work)
    }
    @objc func chooseClip(_ sender: NSMenuItem) {
        if let clip = clips.first(where: { $0.id == sender.tag }) { play(clip) }
    }
    @objc func stopPlayback() {
        player?.stop(); pet.animate(false); captionWork?.cancel(); pet.caption.isHidden = true
    }
    @objc func setVolume(_ sender: NSMenuItem) {
        volume = Float(sender.tag) / 100; player?.volume = volume; defaults.set(volume, forKey: "volume")
    }
    @objc func setSize(_ sender: NSMenuItem) {
        size = CGFloat(sender.tag); panel.setContentSize(panelSize)
        defaults.set(Double(size), forKey: "size"); savePosition()
    }
    @objc func quit() { NSApp.terminate(nil) }
    func applicationWillTerminate(_ notification: Notification) { savePosition(); player?.stop(); pet?.animate(false) }

    func runSelfTest() {
        var failures: [String] = []
        func check(_ valid: Bool, _ name: String) { print("\(valid ? "OK" : "FAIL") \(name)"); if !valid { failures.append(name) } }
        check(clips.count == 10 && Set(clips.map { $0.id }) == Set(1...10), "all 10 LiDaXiao clips present")
        check(pet.caption.maximumNumberOfLines == 0 && pet.caption.lineBreakMode == .byWordWrapping, "captions wrap without truncation")
        check(!panel.isOpaque && panel.backgroundColor == .clear && panel.level == .floating, "transparent floating window")
        check(!panel.canBecomeKey && !panel.canBecomeMain, "does not steal keyboard focus")
        if let data = pet.face.image?.tiffRepresentation, let bitmap = NSBitmapImageRep(data: data) {
            check(bitmap.hasAlpha && (bitmap.colorAt(x: 0, y: 0)?.alphaComponent ?? 1) < 0.1, "original image transparency")
        } else { check(false, "image decoding") }
        for clip in clips {
            do {
                let audio = try AVAudioPlayer(contentsOf: resources.appendingPathComponent("Clips/\(clip.file)"))
                check(audio.duration > 0.25 && abs(audio.duration - clip.duration) < 0.15, "audio \(clip.id): \(clip.label), \(audio.duration)s")
            } catch { check(false, "audio \(clip.id)") }
        }
        var testBag = ShuffleBag(), previous: Int?
        var randomOK = true
        for _ in 0..<100 {
            var cycle: [Int] = []
            for _ in clips {
                let index = testBag.next(count: clips.count)!
                if clips.count > 1 && previous == index { randomOK = false }
                previous = index; cycle.append(index)
            }
            if Set(cycle).count != clips.count { randomOK = false }
        }
        check(randomOK, "100 shuffle rounds: no repeats within a round or at boundary")
        volume = 0
        let event = NSEvent.mouseEvent(with: .leftMouseDown, location: .zero, modifierFlags: [], timestamp: 0, windowNumber: panel.windowNumber, context: nil, eventNumber: 0, clickCount: 1, pressure: 1)!
        pet.mouseDown(with: event); pet.mouseUp(with: event)
        check(player?.isPlaying == true && pet.speaking, "mouse click starts playback and animation")
        let previousPlayer = player
        playNext()
        check(previousPlayer?.isPlaying == false && player?.isPlaying == true, "new click replaces previous audio")
        let beforeDrag = lastPlayed
        pet.mouseDown(with: event)
        let drag = NSEvent.mouseEvent(with: .leftMouseDragged, location: NSPoint(x: 30, y: 20), modifierFlags: [], timestamp: 1, windowNumber: panel.windowNumber, context: nil, eventNumber: 1, clickCount: 1, pressure: 1)!
        pet.mouseDragged(with: drag); pet.mouseUp(with: drag)
        check(pet.dragged && lastPlayed == beforeDrag, "drag moves without playing a new clip")
        check(makeMenu().items.first(where: { $0.title == "挑一句" })?.submenu?.items.count == clips.count, "all clips in context menu")
        stopPlayback()
        check(player?.isPlaying == false && !pet.speaking && pet.caption.isHidden, "stop clears audio, animation and caption")
        if let i = CommandLine.arguments.firstIndex(of: "--preview"), i + 1 < CommandLine.arguments.count {
            showCaption(clips[0].label, seconds: 5)
            pet.layoutSubtreeIfNeeded()
            if let bitmap = pet.bitmapImageRepForCachingDisplay(in: pet.bounds) {
                pet.cacheDisplay(in: pet.bounds, to: bitmap)
                try? bitmap.representation(using: .png, properties: [:])?.write(to: URL(fileURLWithPath: CommandLine.arguments[i + 1]))
            }
        }
        print(failures.isEmpty ? "PASS" : "FAIL: \(failures)"); fflush(stdout)
        exit(failures.isEmpty ? 0 : 1)
    }
}
let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.accessory)
app.run()
