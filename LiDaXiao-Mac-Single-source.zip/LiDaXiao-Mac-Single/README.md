# 李大霄桌宠 · macOS 单人版

一个透明悬浮的人物桌宠，包含 10 段原声。点击人物随机播放语音和字幕，拖动可以移动位置，右键可以挑选台词、调整音量和大小或退出。运行不联网，无接话联动。

## 系统要求

- Apple Silicon Mac，即 M 系列芯片。
- macOS 14 或更新版本。
- 从源码构建需要 Xcode Command Line Tools；使用构建好的应用不需要开发工具、Python 或语音识别模型。

当前项目已在 Windows 上完成素材迁移及静态检查，尚未在 Mac 上编译或实机验证。以下步骤需要在符合要求的 Mac 上执行。

## 从源码构建并运行

### 1. 复制项目到 Mac

将整个 `LiDaXiao-Mac-Single` 文件夹复制到 Mac，例如放到桌面。请保留文件夹中的源码、素材、构建脚本和许可文件，不要只复制 `build.sh`。

### 2. 安装编译工具

打开 Mac 的“终端”，执行：

```bash
xcode-select --install
```

按系统提示完成安装。已经安装 Xcode Command Line Tools 或配置好完整 Xcode 时，无需重复安装。

### 3. 进入项目并构建

如果项目放在桌面，执行：

```bash
cd ~/Desktop/LiDaXiao-Mac-Single
chmod +x build.sh
./build.sh --package
```

如果放在其他位置，请将第一条命令中的路径替换为实际位置；路径含空格时用双引号包住。

脚本会依次完成环境检查、编译、复制素材、生成应用信息、本地签名、原生自检和 ZIP 打包。只有自检输出 `PASS` 且后续打包成功，才算本次构建完成。

生成的文件：

```text
build/李大霄桌宠.app                         可运行应用
dist/LiDaXiaoPet-macOS-arm64-1.0.0.zip       分享用 ZIP
dist/LiDaXiaoPet-macOS-arm64-1.0.0.zip.sha256 校验文件
```

### 4. 启动桌宠

```bash
open "build/李大霄桌宠.app"
```

也可以在 Finder 中进入 `build` 文件夹，双击“李大霄桌宠.app”。需要长期使用时，将该应用拖入“应用程序”文件夹。

以后直接打开应用即可，不用每次重新构建。更换素材或修改代码后才需要重新构建，并先退出旧程序，再打开新版。

## 如何分享给别人

将 `dist/LiDaXiaoPet-macOS-arm64-1.0.0.zip` 发给对方。

对方使用符合系统要求的 Mac：

1. 用 Finder 双击 ZIP，完整解压。
2. 将“李大霄桌宠.app”拖入“应用程序”。
3. 双击应用启动。

接收者不需要安装 Xcode、Python 或其他开发工具。请发送完整 ZIP，不要从 `.app` 内部单独取出可执行文件。

应用采用临时本地签名，未经 Apple 公证。首次打开如果被系统拦截，可以先尝试右键应用选择“打开”，或在“系统设置 → 隐私与安全性”中按系统提示允许打开。

## 操作方式

| 操作 | 效果 |
| --- | --- |
| 单击人物 | 随机播放一句原声，显示字幕和轻微动画 |
| 播放中再次单击 | 停止当前语音，切换下一句 |
| 按住左键拖动 | 移动桌宠，退出后记住位置 |
| 右键人物 | 挑选台词、停止播放、调整音量和大小、复位或退出 |
| 点击菜单栏“大霄” | 打开设置菜单 |

一轮内台词不重复，相邻两轮之间也不会连续播放同一句。应用不在 Dock 中显示图标，退出请使用右键或菜单栏菜单。

## 项目结构

```text
Assets/
  face.png                 透明人物图
  AppIcon.icns             Mac 应用图标
  clips.json               10 段音频的编号、字幕、文件名和实际时长
  Clips/01.wav–10.wav       原声音频
Sources/main.swift         窗口、交互、音频、字幕、设置和原生自检
Tools/make-icon.swift      图标生成工具
Tools/validate-assets.py   素材检查工具
build.sh                   构建、自检和 ZIP 打包脚本
MATERIALS.md               素材来源和说明
LICENSE                    上游代码许可
LICENSE-SunPet             复用代码的许可及署名
```

## 更换素材

- 替换 `Assets/face.png`，使用透明背景 PNG。
- 音频放入 `Assets/Clips/`。本项目统一使用 44.1 kHz、16 位 PCM、单声道 WAV。
- 更新 `Assets/clips.json`，每条记录包含唯一的 `id`、字幕 `label`、文件名 `file` 和实际时长 `duration`（秒）。
- 当前自检按 10 段台词核对；新增或删除台词时，同时更新 `Sources/main.swift` 和 `Tools/validate-assets.py` 中的数量及编号检查。
- 修改后重新运行 `./build.sh --package`，再退出旧程序并打开新版。

在 Mac 上根据人物图重新生成应用图标：

```bash
swift Tools/make-icon.swift
iconutil -c icns Work/AppIcon.iconset -o Assets/AppIcon.icns
```

素材检查工具是可选的，需要 Python 和 Pillow；不是构建或运行依赖：

```bash
python3 -m pip install Pillow
python3 Tools/validate-assets.py
```

## 其他构建命令

只构建、自检，不生成 ZIP：

```bash
./build.sh
```

设置版本号后构建和打包：

```bash
PET_VERSION=1.0.1 PET_BUILD=2 ./build.sh --package
```

输出文件名将使用对应版本号。请勿在未通过自检的情况下分发应用。

## 常见问题

| 问题 | 处理方式 |
| --- | --- |
| `Permission denied` | 在项目目录运行 `chmod +x build.sh` 后重试 |
| 找不到 `swiftc` | 先完成 `xcode-select --install` |
| 提示只能在 macOS 或 Apple Silicon 上构建 | 请使用 M 系列 Mac，本版本不支持 Windows 或 Intel Mac 构建 |
| 双击后 Dock 没有图标 | 属于正常行为，查看菜单栏“大霄”和桌面人物 |
| 没有声音 | 检查桌宠菜单里的音量，以及 Mac 系统输出设备和音量 |
| 人物找不到了 | 点击菜单栏“大霄”→“移回屏幕右下角” |
| 更新后还是旧内容 | 从菜单退出旧程序，再打开新构建的应用 |
| 自检出现 `FAIL` | 保留完整终端输出，先修复错误；不要使用旧 ZIP 代替本次构建结果 |

## 来源和许可

基于 [yuhanfu513-ops/FengGe-Desktop-Pet](https://github.com/yuhanfu513-ops/FengGe-Desktop-Pet) 的独立单人物版本修改。原始 MIT 代码许可和 SunPet 署名保留在 `LICENSE`、`LICENSE-SunPet`。

人物图片、肖像和原声的权利归相应权利人，代码许可不包含这些素材。详见 `MATERIALS.md`。
